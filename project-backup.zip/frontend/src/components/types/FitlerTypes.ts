// FilterTypes.ts - FIXED import and type issues

export interface FilterCriteria {
  regions?: string[];
  nodeTypes?: string[];
  sales_regions?: string[];
  channels?: string[];
  ratings?: string[];
  influenceLevels?: string[];
  assetClasses?: string[];
  consultantIds?: string[];
  fieldConsultantIds?: string[];
  clientIds?: string[];
  productIds?: string[];
  pcaIds?: string[];
  acaIds?: string[];
  mandateStatuses?: string[];
  showInactive?: boolean;
}

export interface FilterOptions {
  regions: string[];
  sales_regions: string[];
  channels: string[];
  assetClasses: string[];
  consultants: string[];
  fieldConsultants: string[];
  clients: string[];
  products: string[];
  incumbent_products: string[];
  pcas: string[];
  acas: string[];
  ratings: string[];
  influenceLevels: string[];
  mandateStatuses: string[];
  jpm_flags: string[];
  privacy_levels: string[];
}

// ✅ FIXED: Proper interface definition with all required fields
export interface HierarchicalFilterOptions {
  markets?: string[];
  channels?: string[];
  asset_classes?: string[];
  consultants?: Array<{id: string, name: string}> | string[];
  field_consultants?: Array<{id: string, name: string}> | string[];
  companies?: Array<{id: string, name: string}> | string[];
  products?: Array<{id: string, name: string}> | string[];
  incumbent_products?: Array<{id: string, name: string}> | string[];
  pcas?: string[];
  acas?: string[];
  consultant_rankings?: string[];
  influence_levels?: string[];
  mandate_statuses?: string[];
  jpm_flags?: string[];
  privacy_levels?: string[];
  client_advisors?: string[];
}

// ✅ FIXED: Export as regular function, not type-only
export function transformHierarchicalOptions(hierarchicalOptions: HierarchicalFilterOptions | Record<string, any>): FilterOptions {
  // ✅ FIXED: Handle both typed and untyped inputs
  const options = hierarchicalOptions as HierarchicalFilterOptions;
  
  const extractNames = (arr: Array<{id: string, name: string}> | string[] | undefined): string[] => {
    if (!arr || arr.length === 0) return [];
    return arr.map(item => typeof item === 'string' ? item : item.name || item.id);
  };

  return {
    regions: ['NAI', 'EMEA', 'APAC'],
    sales_regions: options.markets || [],
    channels: options.channels || [],
    assetClasses: options.asset_classes || [],
    consultants: extractNames(options.consultants),
    fieldConsultants: extractNames(options.field_consultants),
    clients: extractNames(options.companies),
    products: extractNames(options.products),
    incumbent_products: extractNames(options.incumbent_products),
    pcas: options.pcas || [],
    acas: options.acas || [],
    ratings: options.consultant_rankings || ['Positive', 'Negative', 'Neutral', 'Introduced'],
    influenceLevels: options.influence_levels || ['1', '2', '3', '4'],
    mandateStatuses: options.mandate_statuses || ['Active', 'At Risk', 'Conversion in Progress'],
    jpm_flags: options.jpm_flags || ['Y', 'N'],
    privacy_levels: options.privacy_levels || ['Public', 'Private', 'Confidential']
  };
}