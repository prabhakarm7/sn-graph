// components/StatsCards.tsx
import React, { useState } from 'react';
import { Box, Typography, Switch, FormControlLabel, IconButton, Tooltip } from '@mui/material';
import { 
  Hub, 
  Psychology, 
  BugReport, 
  DarkMode, 
  LightMode 
} from '@mui/icons-material';
import { Node, Edge } from 'reactflow';
import { AppNodeData, EdgeData } from '../types/GraphTypes';

interface StatsCardsProps {
  nodes: Node<AppNodeData>[];
  edges: Edge<EdgeData>[];
  showDebug?: boolean;
  setShowDebug?: (show: boolean) => void;
  isDarkTheme?: boolean;
  setIsDarkTheme?: (isDark: boolean) => void;
}

export const StatsCards: React.FC<StatsCardsProps> = ({ 
  nodes, 
  edges, 
  showDebug = true, 
  setShowDebug = () => {},
  isDarkTheme = true,
  setIsDarkTheme = () => {}
}) => {
  const [productRecommendations, setProductRecommendations] = useState(false);

  return (
    <Box sx={{ 
      position: 'absolute', 
      top: 16, 
      left: 16,
      right: 16,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      pointerEvents: 'none', // Allow clicking through the container
      '& > *': { pointerEvents: 'auto' } // Re-enable pointer events for children
    }}>
      {/* Left Side - Smart Network Title */}
      <Box sx={{
        display: 'flex',
        alignItems: 'center',
        gap: 2,
        bgcolor: 'rgba(15, 23, 42, 0.9)',
        backdropFilter: 'blur(20px)',
        border: '1px solid rgba(255, 255, 255, 0.1)',
        borderRadius: 3,
        px: 3,
        py: 1.5,
        boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)'
      }}>
        <Box sx={{
          display: 'flex',
          alignItems: 'center',
          gap: 1,
          p: 1,
          borderRadius: 2,
          bgcolor: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)',
          background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)'
        }}>
          <Hub sx={{ color: 'white', fontSize: '1.3rem' }} />
        </Box>
        <Box>
          <Typography variant="h6" sx={{ 
            color: 'white', 
            fontWeight: 'bold',
            background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)',
            backgroundClip: 'text',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            letterSpacing: '0.5px',
            fontSize: '1.1rem'
          }}>
            SMART NETWORK
          </Typography>
          <Typography variant="caption" sx={{ 
            color: 'rgba(255, 255, 255, 0.7)',
            fontWeight: 'medium',
            fontSize: '0.7rem'
          }}>
            Welcome, Prabhakar
          </Typography>
        </Box>
      </Box>

      {/* Right Side - Controls Panel */}
      <Box sx={{
        display: 'flex',
        alignItems: 'center',
        gap: 1,
        bgcolor: 'rgba(15, 23, 42, 0.9)',
        backdropFilter: 'blur(20px)',
        border: '1px solid rgba(255, 255, 255, 0.1)',
        borderRadius: 3,
        px: 2,
        py: 1,
        boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)'
      }}>
        {/* Product Recommendations Toggle */}
        <FormControlLabel
          control={
            <Switch
              checked={productRecommendations}
              onChange={(e) => setProductRecommendations(e.target.checked)}
              sx={{
                '& .MuiSwitch-switchBase.Mui-checked': { 
                  color: '#10b981',
                  '&:hover': {
                    bgcolor: 'rgba(16, 185, 129, 0.08)'
                  }
                },
                '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': { 
                  backgroundColor: '#10b981'
                },
                '& .MuiSwitch-track': {
                  backgroundColor: 'rgba(255, 255, 255, 0.3)'
                }
              }}
            />
          }
          label={
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Psychology sx={{ 
                color: productRecommendations ? '#10b981' : 'rgba(255, 255, 255, 0.7)', 
                fontSize: '1.2rem',
                transition: 'color 0.2s ease'
              }} />
              <Typography variant="body2" sx={{ 
                color: 'white', 
                fontWeight: 'medium',
                lineHeight: 1,
                fontSize: '0.85rem'
              }}>
                Product Recommendations
              </Typography>
            </Box>
          }
          sx={{ m: 0, mr: 1 }}
        />

        {/* Divider */}
        <Box sx={{
          width: '1px',
          height: '24px',
          bgcolor: 'rgba(255, 255, 255, 0.2)',
          mx: 1
        }} />

        {/* Debug Toggle Button */}
        <Tooltip title={showDebug ? "Hide Debug Panel" : "Show Debug Panel"} arrow>
          <IconButton
            onClick={() => setShowDebug(!showDebug)}
            sx={{
              color: showDebug ? '#f59e0b' : 'rgba(255, 255, 255, 0.7)',
              bgcolor: showDebug ? 'rgba(245, 158, 11, 0.15)' : 'transparent',
              border: showDebug ? '1px solid rgba(245, 158, 11, 0.3)' : '1px solid transparent',
              borderRadius: 2,
              p: 1,
              transition: 'all 0.2s ease',
              '&:hover': {
                bgcolor: showDebug ? 'rgba(245, 158, 11, 0.25)' : 'rgba(255, 255, 255, 0.1)',
                color: showDebug ? '#f59e0b' : 'white'
              }
            }}
          >
            <BugReport fontSize="small" />
          </IconButton>
        </Tooltip>

        {/* Theme Toggle Button */}
        <Tooltip title={isDarkTheme ? "Switch to Light Theme" : "Switch to Dark Theme"} arrow>
          <IconButton
            onClick={() => setIsDarkTheme(!isDarkTheme)}
            sx={{
              color: isDarkTheme ? '#6366f1' : '#f59e0b',
              bgcolor: isDarkTheme ? 'rgba(99, 102, 241, 0.15)' : 'rgba(245, 158, 11, 0.15)',
              border: isDarkTheme ? '1px solid rgba(99, 102, 241, 0.3)' : '1px solid rgba(245, 158, 11, 0.3)',
              borderRadius: 2,
              p: 1,
              transition: 'all 0.2s ease',
              '&:hover': {
                bgcolor: isDarkTheme ? 'rgba(99, 102, 241, 0.25)' : 'rgba(245, 158, 11, 0.25)',
                transform: 'scale(1.05)'
              }
            }}
          >
            {isDarkTheme ? <DarkMode fontSize="small" /> : <LightMode fontSize="small" />}
          </IconButton>
        </Tooltip>
      </Box>
    </Box>
  );
};