// components/InsightsPanel.tsx - FIXED to properly display edge data
import React from 'react';
import { 
  Box, 
  Typography, 
  Chip, 
  LinearProgress, 
  Avatar,
  Stack,
  Divider
} from '@mui/material';
import { 
  Person, 
  Business, 
  AccountBalance, 
  TrendingUp,
  Timeline,
  Star,
  Speed,
  Assessment,
  BusinessCenter,
  CorporateFare,
  ShowChart,
  Analytics
} from '@mui/icons-material';
import { Node, Edge } from 'reactflow';
import { AppNodeData, EdgeData } from '../types/GraphTypes';

interface InsightsPanelProps {
  selectedNode?: Node<AppNodeData> | null;
  selectedEdge?: Edge<EdgeData> | null;
  isHovered?: boolean;
}

export const InsightsPanel: React.FC<InsightsPanelProps> = ({ 
  selectedNode, 
  selectedEdge,
  isHovered = false 
}) => {
  const getNodeIcon = (type?: string) => {
    switch (type) {
      case 'CONSULTANT': return <BusinessCenter sx={{ color: '#6366f1', fontSize: '1.5rem' }} />;
      case 'FIELD_CONSULTANT': return <Person sx={{ color: '#6366f1', fontSize: '1.5rem' }} />;
      case 'COMPANY': return <CorporateFare sx={{ color: '#10b981', fontSize: '1.5rem' }} />;
      case 'PRODUCT': return <AccountBalance sx={{ color: '#3b82f6', fontSize: '1.5rem' }} />;
      case 'INCUMBENT_PRODUCT': return <AccountBalance sx={{ color: '#3b82f6', fontSize: '1.5rem' }} />;
      default: return <Assessment sx={{ color: '#6b7280', fontSize: '1.5rem' }} />;
    }
  };

  const getNodeTypeColor = (type?: string) => {
    switch (type) {
      case 'CONSULTANT': 
      case 'FIELD_CONSULTANT': 
        return '#6366f1';
      case 'COMPANY': 
        return '#10b981';
      case 'PRODUCT': 
      case 'INCUMBENT_PRODUCT':
        return '#3b82f6';
      default: 
        return '#6b7280';
    }
  };

  const formatNodeType = (type?: string) => {
    return type?.replace('_', ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase()) || 'Unknown';
  };

  const getRelationshipIcon = (relType?: string) => {
    switch (relType) {
      case 'EMPLOYS': return <Person sx={{ color: '#6366f1', fontSize: '1.5rem' }} />;
      case 'COVERS': return <Business sx={{ color: '#10b981', fontSize: '1.5rem' }} />;
      case 'RATES': return <Star sx={{ color: '#8b5cf6', fontSize: '1.5rem' }} />;
      case 'OWNS': return <TrendingUp sx={{ color: '#3b82f6', fontSize: '1.5rem' }} />;
      default: return <Timeline sx={{ color: '#6b7280', fontSize: '1.5rem' }} />;
    }
  };

  const getRelationshipColor = (relType?: string) => {
    switch (relType) {
      case 'EMPLOYS': return '#6366f1';
      case 'COVERS': return '#10b981';
      case 'RATES': return '#8b5cf6';
      case 'OWNS': return '#3b82f6';
      default: return '#6b7280';
    }
  };

  if (!selectedNode && !selectedEdge) {
    return (
      <Box sx={{ 
        width: '100%', 
        height: '100%', 
        display: 'flex', 
        alignItems: 'center',
        px: 3
      }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <Assessment sx={{ color: 'rgba(255, 255, 255, 0.6)', fontSize: '2rem' }} />
          <Box>
            <Typography variant="h6" sx={{ color: 'white', fontWeight: 'bold', mb: 0.5 }}>
              Network Insights
            </Typography>
            <Typography variant="body2" sx={{ color: 'rgba(255, 255, 255, 0.7)' }}>
              {isHovered ? 'Hover over any node or connection to preview details' : 'Select any node or connection to view detailed insights and analytics'}
            </Typography>
          </Box>
        </Box>
      </Box>
    );
  }

  if (selectedNode) {
    const { data, type } = selectedNode;
    
    return (
      <Box sx={{ 
        width: '100%', 
        height: '100%', 
        display: 'flex', 
        alignItems: 'center',
        px: 3,
        gap: 3,
        background: isHovered ? 'linear-gradient(90deg, rgba(99, 102, 241, 0.1) 0%, transparent 100%)' : 'transparent',
        transition: 'background 0.3s ease',
        borderLeft: isHovered ? '3px solid #6366f1' : '3px solid transparent'
      }}>
        {/* Primary Info */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, minWidth: 300 }}>
          <Avatar sx={{ 
            bgcolor: 'rgba(255, 255, 255, 0.1)', 
            width: 48, 
            height: 48,
            border: `2px solid ${getNodeTypeColor(type)}`,
            boxShadow: isHovered ? `0 0 20px ${getNodeTypeColor(type)}40` : 'none',
            transition: 'box-shadow 0.3s ease'
          }}>
            {getNodeIcon(type)}
          </Avatar>
          <Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
              <Typography variant="h6" sx={{ color: 'white', fontWeight: 'bold' }}>
                {data.name}
              </Typography>
              {isHovered && (
                <Chip 
                  label="HOVER" 
                  size="small" 
                  sx={{ 
                    bgcolor: '#6366f120',
                    color: '#6366f1',
                    fontWeight: 'bold',
                    fontSize: '0.65rem',
                    height: 20
                  }}
                />
              )}
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Chip 
                label={`ID: ${data.id}`}
                size="small" 
                sx={{ 
                  bgcolor: `${getNodeTypeColor(type)}20`,
                  color: getNodeTypeColor(type),
                  fontWeight: 'bold',
                  fontSize: '0.75rem'
                }}
              />
              <Chip 
                label={formatNodeType(type)} 
                size="small" 
                sx={{ 
                  bgcolor: `${getNodeTypeColor(type)}30`,
                  color: getNodeTypeColor(type),
                  fontWeight: 'bold',
                  fontSize: '0.75rem'
                }}
              />
            </Box>
          </Box>
        </Box>

        <Divider orientation="vertical" flexItem sx={{ borderColor: 'rgba(255, 255, 255, 0.1)' }} />

        {/* Performance Metrics */}
        {data.performance && (
          <Box sx={{ minWidth: 200 }}>
            <Typography variant="subtitle2" sx={{ color: 'white', mb: 1, display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <Speed sx={{ fontSize: '1rem' }} />
              Performance Score
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              <LinearProgress 
                variant="determinate" 
                value={data.performance} 
                sx={{ 
                  flexGrow: 1,
                  height: 8, 
                  borderRadius: 4,
                  bgcolor: 'rgba(255, 255, 255, 0.1)',
                  '& .MuiLinearProgress-bar': {
                    bgcolor: data.performance >= 80 ? '#10b981' : 
                             data.performance >= 60 ? '#f59e0b' : '#ef4444',
                    borderRadius: 4
                  }
                }}
              />
              <Typography variant="h6" sx={{ 
                color: data.performance >= 80 ? '#10b981' : 
                       data.performance >= 60 ? '#f59e0b' : '#ef4444',
                fontWeight: 'bold',
                minWidth: 'fit-content'
              }}>
                {data.performance}%
              </Typography>
            </Box>
          </Box>
        )}

        {/* Influence Level */}
        {data.influence && (
          <>
            <Divider orientation="vertical" flexItem sx={{ borderColor: 'rgba(255, 255, 255, 0.1)' }} />
            <Box sx={{ minWidth: 180 }}>
              <Typography variant="subtitle2" sx={{ color: 'white', mb: 1, display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <Star sx={{ fontSize: '1rem' }} />
                Influence Level
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <LinearProgress 
                  variant="determinate" 
                  value={data.influence} 
                  sx={{ 
                    flexGrow: 1,
                    height: 8, 
                    borderRadius: 4,
                    bgcolor: 'rgba(255, 255, 255, 0.1)',
                    '& .MuiLinearProgress-bar': {
                      bgcolor: '#fbbf24',
                      borderRadius: 4
                    }
                  }}
                />
                <Typography variant="h6" sx={{ 
                  color: '#fbbf24',
                  fontWeight: 'bold',
                  minWidth: 'fit-content'
                }}>
                  {data.influence}%
                </Typography>
              </Box>
            </Box>
          </>
        )}

        {/* Product Ratings Display */}
        {type === 'PRODUCT' && data.ratings && data.ratings.length > 0 && (
          <>
            <Divider orientation="vertical" flexItem sx={{ borderColor: 'rgba(255, 255, 255, 0.1)' }} />
            <Box sx={{ minWidth: 250 }}>
              <Typography variant="subtitle2" sx={{ color: 'white', mb: 1, display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <Assessment sx={{ fontSize: '1rem' }} />
                Consultant Ratings ({data.ratings.length})
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                {data.ratings.slice(0, 4).map((rating: any, index: number) => (
                  <Chip
                    key={index}
                    label={`${rating.consultant}: ${rating.rankgroup || rating.rating}`}
                    size="small"
                    sx={{
                      bgcolor: rating.rankgroup === 'Positive' ? '#16a34a20' : 
                               rating.rankgroup === 'Negative' ? '#dc262620' : 
                               rating.rankgroup === 'Introduced' ? '#089bb220' : '#6b728020',
                      color: rating.rankgroup === 'Positive' ? '#16a34a' : 
                             rating.rankgroup === 'Negative' ? '#dc2626' : 
                             rating.rankgroup === 'Introduced' ? '#0891b2' : '#6b7280',
                      fontWeight: 'bold',
                      fontSize: '0.7rem'
                    }}
                  />
                ))}
              </Box>
            </Box>
          </>
        )}

        {/* Additional Details - Spread from left to right */}
        <Box sx={{ flexGrow: 1, display: 'flex', alignItems: 'center', justifyContent: 'flex-start', pl: 2 }}>
          <Stack direction="row" spacing={4} alignItems="center" sx={{ width: '100%' }}>
            {data.region && (
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)', display: 'block' }}>
                  Region
                </Typography>
                <Typography variant="body2" sx={{ color: 'white', fontWeight: 'medium' }}>
                  {data.region}
                </Typography>
              </Box>
            )}
            
            {data.pca && (
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)', display: 'block' }}>
                  PCA
                </Typography>
                <Typography variant="body2" sx={{ color: 'white', fontWeight: 'medium' }}>
                  {data.pca}
                </Typography>
              </Box>
            )}

            {data.aca && (
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)', display: 'block' }}>
                  ACA
                </Typography>
                <Typography variant="body2" sx={{ color: 'white', fontWeight: 'medium' }}>
                  {data.aca}
                </Typography>
              </Box>
            )}

            {data.sales_region && (
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)', display: 'block' }}>
                  Sales Region
                </Typography>
                <Typography variant="body2" sx={{ color: 'white', fontWeight: 'medium' }}>
                  {data.sales_region}
                </Typography>
              </Box>
            )}

            {data.channel && (
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)', display: 'block' }}>
                  Channel
                </Typography>
                <Typography variant="body2" sx={{ color: 'white', fontWeight: 'medium' }}>
                  {data.channel}
                </Typography>
              </Box>
            )}

            {data.privacy && (
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)', display: 'block' }}>
                  Privacy
                </Typography>
                <Typography variant="body2" sx={{ color: 'white', fontWeight: 'medium' }}>
                  {data.privacy}
                </Typography>
              </Box>
            )}

            {data.asset_class && (
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)', display: 'block' }}>
                  Asset Class
                </Typography>
                <Typography variant="body2" sx={{ color: 'white', fontWeight: 'medium' }}>
                  {data.asset_class}
                </Typography>
              </Box>
            )}

            {data.product_label && (
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)', display: 'block' }}>
                  Product Label
                </Typography>
                <Typography variant="body2" sx={{ color: 'white', fontWeight: 'medium' }}>
                  {data.product_label}
                </Typography>
              </Box>
            )}

            {/* Show parentConsultantId for field consultants */}
            {type === 'FIELD_CONSULTANT' && data.parentConsultantId && (
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)', display: 'block' }}>
                  Parent Consultant
                </Typography>
                <Typography variant="body2" sx={{ color: '#6366f1', fontWeight: 'medium' }}>
                  {data.parentConsultantId}
                </Typography>
              </Box>
            )}
          </Stack>
        </Box>
      </Box>
    );
  }

  if (selectedEdge) {
    // 🆕 FIXED: Enhanced edge data access with multiple fallback patterns
    const edgeData = selectedEdge.data || {};
    const relType = edgeData.relType;
    
    // Try multiple property names for mandate status
    const mandateStatus = edgeData.mandateStatus || edgeData.mandate_status || edgeData.status;
    
    // Try multiple property names for level of influence
    const levelOfInfluence = edgeData.levelOfInfluence || edgeData.level_of_influence || edgeData.influence;
    
    // Try multiple property names for strength
    const strength = edgeData.strength || edgeData.weight;
    
    // Try multiple property names for source/target IDs
    const sourceId = edgeData.sourceId || edgeData.source_id || selectedEdge.source;
    const targetId = edgeData.targetId || edgeData.target_id || selectedEdge.target;
    
    // Try multiple property names for rating
    const rating = edgeData.rating || edgeData.rankgroup || edgeData.rank;
    
    const influencedConsultant = edgeData.influencedConsultant || edgeData.influenced_consultant;
    
    console.log('🔍 INSIGHTS PANEL: Edge data debug:', {
      edgeId: selectedEdge.id,
      relType,
      mandateStatus,
      levelOfInfluence,
      strength,
      rating,
      sourceId,
      targetId,
      influencedConsultant,
      rawData: edgeData
    });
    
    return (
      <Box sx={{ 
        width: '100%', 
        height: '100%', 
        display: 'flex', 
        alignItems: 'center',
        px: 3,
        gap: 3,
        background: isHovered ? (() => {
          const color = getRelationshipColor(relType);
          if (color && color.startsWith('#')) {
            const r = parseInt(color.slice(1, 3), 16);
            const g = parseInt(color.slice(3, 5), 16);  
            const b = parseInt(color.slice(5, 7), 16);
            return `linear-gradient(90deg, rgba(${r}, ${g}, ${b}, 0.1) 0%, transparent 100%)`;
          }
          return 'linear-gradient(90deg, rgba(107, 114, 128, 0.1) 0%, transparent 100%)';
        })() : 'transparent',
        transition: 'background 0.3s ease',
        borderLeft: isHovered ? `3px solid ${getRelationshipColor(relType)}` : '3px solid transparent'
      }}>
        {/* Connection Info */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, minWidth: 300 }}>
          <Avatar sx={{ 
            bgcolor: 'rgba(255, 255, 255, 0.1)', 
            width: 48, 
            height: 48,
            border: `2px solid ${getRelationshipColor(relType)}`,
            boxShadow: isHovered ? `0 0 20px ${getRelationshipColor(relType)}40` : 'none',
            transition: 'box-shadow 0.3s ease'
          }}>
            {getRelationshipIcon(relType)}
          </Avatar>
          <Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
              <Typography variant="h6" sx={{ color: 'white', fontWeight: 'bold' }}>
                {relType || 'Connection'}
              </Typography>
              {isHovered && (
                <Chip 
                  label="HOVER" 
                  size="small" 
                  sx={{ 
                    bgcolor: `${getRelationshipColor(relType)}20`,
                    color: getRelationshipColor(relType),
                    fontWeight: 'bold',
                    fontSize: '0.65rem',
                    height: 20
                  }}
                />
              )}
            </Box>
            <Chip 
              label="Relationship" 
              size="small" 
              sx={{ 
                bgcolor: `${getRelationshipColor(relType)}20`,
                color: getRelationshipColor(relType),
                fontWeight: 'bold',
                fontSize: '0.75rem'
              }}
            />
          </Box>
        </Box>

        <Divider orientation="vertical" flexItem sx={{ borderColor: 'rgba(255, 255, 255, 0.1)' }} />

        {/* 🆕 ENHANCED: Level of Influence for COVERS relationship */}
        {relType === 'COVERS' && levelOfInfluence && (
          <Box sx={{ minWidth: 200 }}>
            <Typography variant="subtitle2" sx={{ color: 'white', mb: 1, display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <Star sx={{ fontSize: '1rem' }} />
              Level of Influence
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              <LinearProgress 
                variant="determinate" 
                value={(Number(levelOfInfluence) / 4) * 100} 
                sx={{ 
                  flexGrow: 1,
                  height: 8, 
                  borderRadius: 4,
                  bgcolor: 'rgba(255, 255, 255, 0.1)',
                  '& .MuiLinearProgress-bar': {
                    bgcolor: Number(levelOfInfluence) >= 3 ? '#10b981' : 
                             Number(levelOfInfluence) >= 2 ? '#f59e0b' : '#ef4444',
                    borderRadius: 4
                  }
                }}
              />
              <Typography variant="h6" sx={{ 
                color: Number(levelOfInfluence) >= 3 ? '#10b981' : 
                       Number(levelOfInfluence) >= 2 ? '#f59e0b' : '#ef4444',
                fontWeight: 'bold',
                minWidth: 'fit-content'
              }}>
                {levelOfInfluence}/4
              </Typography>
            </Box>
          </Box>
        )}

        {/* Connection Strength for other relationships */}
        {relType !== 'COVERS' && strength && (
          <Box sx={{ minWidth: 200 }}>
            <Typography variant="subtitle2" sx={{ color: 'white', mb: 1 }}>
              Connection Strength
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              <LinearProgress 
                variant="determinate" 
                value={Number(strength)} 
                sx={{ 
                  flexGrow: 1,
                  height: 8, 
                  borderRadius: 4,
                  bgcolor: 'rgba(255, 255, 255, 0.1)',
                  '& .MuiLinearProgress-bar': {
                    bgcolor: Number(strength) >= 80 ? '#10b981' : 
                             Number(strength) >= 60 ? '#f59e0b' : '#ef4444',
                    borderRadius: 4
                  }
                }}
              />
              <Typography variant="h6" sx={{ 
                color: Number(strength) >= 80 ? '#10b981' : 
                       Number(strength) >= 60 ? '#f59e0b' : '#ef4444',
                fontWeight: 'bold',
                minWidth: 'fit-content'
              }}>
                {strength}%
              </Typography>
            </Box>
          </Box>
        )}

        {/* Additional Details - Spread from left to right */}
        <Box sx={{ flexGrow: 1, display: 'flex', alignItems: 'center', justifyContent: 'flex-start', pl: 2 }}>
          <Stack direction="row" spacing={4} alignItems="center" sx={{ width: '100%' }}>
            {sourceId && (
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)', display: 'block' }}>
                  Source ID
                </Typography>
                <Typography variant="body2" sx={{ color: 'white', fontWeight: 'medium' }}>
                  {sourceId}
                </Typography>
              </Box>
            )}
            
            {targetId && (
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)', display: 'block' }}>
                  Target ID
                </Typography>
                <Typography variant="body2" sx={{ color: 'white', fontWeight: 'medium' }}>
                  {targetId}
                </Typography>
              </Box>
            )}

            {rating && (
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)', display: 'block' }}>
                  Rating
                </Typography>
                <Chip
                  label={rating}
                  size="small"
                  sx={{
                    bgcolor: rating === 'Positive' ? '#16a34a' : 
                             rating === 'Negative' ? '#dc2626' : 
                             rating === 'Introduced' ? '#0891b2' : '#6b7280',
                    color: 'white',
                    fontWeight: 'bold'
                  }}
                />
              </Box>
            )}

            {mandateStatus && (
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)', display: 'block' }}>
                  Mandate Status
                </Typography>
                <Chip
                  label={mandateStatus}
                  size="small"
                  sx={{
                    bgcolor: mandateStatus === 'Active' ? '#10b981' : 
                             mandateStatus === 'Conversion in Progress' ? '#f59e0b' : 
                             mandateStatus === 'At Risk' ? '#ef4444' : '#6b7280',
                    color: 'white',
                    fontWeight: 'bold'
                  }}
                />
              </Box>
            )}

            {influencedConsultant && (
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)', display: 'block' }}>
                  Influenced Consultant
                </Typography>
                <Typography variant="body2" sx={{ color: 'white', fontWeight: 'medium' }}>
                  {influencedConsultant}
                </Typography>
              </Box>
            )}

            {/* Show relationship type specific info */}
            {relType === 'EMPLOYS' && (
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)', display: 'block' }}>
                  Relationship Type
                </Typography>
                <Typography variant="body2" sx={{ color: '#6366f1', fontWeight: 'medium' }}>
                  Employment
                </Typography>
              </Box>
            )}

            {relType === 'COVERS' && (
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)', display: 'block' }}>
                  Coverage Type
                </Typography>
                <Typography variant="body2" sx={{ color: '#10b981', fontWeight: 'medium' }}>
                  Client Coverage
                </Typography>
              </Box>
            )}

            {relType === 'OWNS' && (
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)', display: 'block' }}>
                  Ownership Type
                </Typography>
                <Typography variant="body2" sx={{ color: '#3b82f6', fontWeight: 'medium' }}>
                  Product Ownership
                </Typography>
              </Box>
            )}
          </Stack>
        </Box>
      </Box>
    );
  }

  return null;
};