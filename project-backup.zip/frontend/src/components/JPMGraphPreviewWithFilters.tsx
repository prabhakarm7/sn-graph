// JPMGraphPreviewWithFilters.tsx - Updated for Hierarchical Integration
import React, { useEffect, useRef, useState, useCallback } from 'react';
import ReactFlow, {
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  useReactFlow,
  ReactFlowProvider,
  Node,
  Edge,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { Box, Drawer, Tabs, Tab, Typography, CircularProgress, Alert } from '@mui/material';
import { Chat as ChatIcon, FilterList as FilterIcon } from '@mui/icons-material';

// Import components
import { nodeTypes, edgeTypes } from './components/NodeComponents';
import { ChatInterface } from './components/ChatInterface';
import { WorkingFiltersInterface } from './components/WorkingFiltersInterface';
import { StatsCards } from './components/StatsCards';
import { InsightsPanel } from './components/InsightsPanel';
import { DebugDataDisplay } from './components/DebugDataDisplay';
import { AppNodeData, EdgeData } from './types/GraphTypes';
import { useGraphData } from './hooks/useGraphData';
import { GraphDataProvider } from './context/GraphDataProvider';

// Move nodeTypes and edgeTypes outside component to prevent recreation
const STABLE_NODE_TYPES = nodeTypes;
const STABLE_EDGE_TYPES = edgeTypes;

// Inner component that uses ReactFlow hooks
function GraphComponent() {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const { fitView } = useReactFlow();
  const [selectedNode, setSelectedNode] = useState<Node<AppNodeData> | null>(null);
  const [selectedEdge, setSelectedEdge] = useState<Edge<EdgeData> | null>(null);
  const [hoveredNode, setHoveredNode] = useState<Node<AppNodeData> | null>(null);
  const [hoveredEdge, setHoveredEdge] = useState<Edge<EdgeData> | null>(null);
  const [tabValue, setTabValue] = useState(1); // Start with filters tab
  const [showDebug, setShowDebug] = useState(false); // Debug toggle state
  const [isDarkTheme, setIsDarkTheme] = useState(true); // Theme toggle state

  // Use hierarchical graph data hook
  const { 
    graphData: hookGraphData,
    filterOptions,
    currentFilters,
    currentRegions,
    initialLoading, 
    filterLoading, 
    error,
    changeRegions,
    applyFilters,
    resetFilters,
    getAvailableRegions,
    hasData,
    nodeCount,
    edgeCount
  } = useGraphData();

  // Local graph data state for ReactFlow
  const [graphData, setGraphData] = useState<{ nodes: Node<AppNodeData>[], edges: Edge<EdgeData>[] }>({ 
    nodes: [], 
    edges: [] 
  });

  // Watch for changes in hookGraphData and update local state
  useEffect(() => {
    console.log('🔄 HOOK graphData changed, updating main component state:', {
      nodes: hookGraphData.nodes.length,
      edges: hookGraphData.edges.length
    });
    setGraphData({
      nodes: [...hookGraphData.nodes],
      edges: [...hookGraphData.edges]
    });
  }, [hookGraphData]);

  // DEBUG: Log whenever graphData changes in main component
  useEffect(() => {
    console.log('🎯 MAIN COMPONENT: graphData changed detected:', {
      nodes: graphData.nodes.length,
      edges: graphData.edges.length,
      hasData,
      nodeIds: graphData.nodes.slice(0, 5).map(n => n.id),
      timestamp: Date.now()
    });
  }, [graphData, hasData]);

  const [nodes, setNodes, onNodesChange] = useNodesState<AppNodeData>([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);

  // Update ReactFlow when graphData changes
  useEffect(() => {
    console.log('🔄 MAIN COMPONENT: useEffect triggered - updating ReactFlow:', {
      graphDataNodes: graphData.nodes.length,
      graphDataEdges: graphData.edges.length,
      reactFlowNodes: nodes.length,
      reactFlowEdges: edges.length
    });
    
    if (graphData.nodes.length === 0) {
      console.log('⚠️ MAIN COMPONENT: No data available, clearing ReactFlow');
      setNodes([]);
      setEdges([]);
      return;
    }
    
    console.log('📊 MAIN COMPONENT: Setting ReactFlow nodes and edges...');
    setNodes(graphData.nodes);
    setEdges(graphData.edges);
    
    console.log('✅ MAIN COMPONENT: ReactFlow state updated');
    
    // Apply fitView after a brief delay
    const timeoutId = setTimeout(() => {
      try {
        fitView({ padding: 0.2, duration: 500 });
        console.log('✅ MAIN COMPONENT: FitView applied');
      } catch (error) {
        console.warn('⚠️ MAIN COMPONENT: FitView failed:', error);
      }
    }, 150);
    
    return () => clearTimeout(timeoutId);
  }, [graphData, setNodes, setEdges, fitView]);

  // Debug: Log actual ReactFlow state changes
  useEffect(() => {
    console.log('🔍 MAIN COMPONENT: ReactFlow nodes state changed:', {
      count: nodes.length,
      nodeIds: nodes.slice(0, 5).map(n => n.id),
      sampleNode: nodes[0] ? {
        id: nodes[0].id,
        type: nodes[0].type,
        name: nodes[0].data?.name,
        position: nodes[0].position
      } : null
    });
  }, [nodes]);

  useEffect(() => {
    console.log('🔍 MAIN COMPONENT: ReactFlow edges state changed:', {
      count: edges.length,
      edgeIds: edges.slice(0, 5).map(e => e.id),
      sampleEdge: edges[0] ? {
        id: edges[0].id,
        source: edges[0].source,
        target: edges[0].target,
        type: edges[0].type
      } : null
    });
  }, [edges]);

  useEffect(() => {
    const observerCb: ResizeObserverCallback = (entries) => {
      window.requestAnimationFrame(() => {
        if (!Array.isArray(entries) || !entries.length) return;
      });
    };
    const ro = new ResizeObserver(observerCb);
    if (containerRef.current) ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, []);

  const handleNodeClick = (event: React.MouseEvent, node: Node<AppNodeData>) => {
    setSelectedNode(node);
    setSelectedEdge(null);
  };

  const handleEdgeClick = (event: React.MouseEvent, edge: Edge<EdgeData>) => {
    setSelectedEdge(edge);
    setSelectedNode(null);
  };

  const handleNodeMouseEnter = (event: React.MouseEvent, node: Node<AppNodeData>) => {
    setHoveredNode(node);
    setHoveredEdge(null);
  };

  const handleNodeMouseLeave = () => {
    setHoveredNode(null);
  };

  const handleEdgeMouseEnter = (event: React.MouseEvent, edge: Edge<EdgeData>) => {
    setHoveredEdge(edge);
    setHoveredNode(null);
  };

  const handleEdgeMouseLeave = () => {
    setHoveredEdge(null);
  };

  const handlePaneClick = () => {
    setSelectedNode(null);
    setSelectedEdge(null);
  };

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  // Show loading screen during initial load
  if (initialLoading) {
    return (
      <Box sx={{ 
        display: 'flex', 
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh', 
        background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%)',
        color: 'white'
      }}>
        <CircularProgress sx={{ color: '#6366f1', mb: 2 }} size={60} />
        <Typography variant="h6" sx={{ mb: 1 }}>
          🔗 Loading Hierarchical Network Data
        </Typography>
        <Typography variant="body2" sx={{ color: 'rgba(255, 255, 255, 0.7)' }}>
          Initializing region data for {currentRegions.join(', ')} using hierarchical workflow...
        </Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ 
      display: 'flex', 
      height: '100vh', 
      background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%)',
      position: 'relative'
    }}>
      {/* Main Graph Section */}
      <Box sx={{ 
        flexGrow: 1, 
        display: 'flex', 
        flexDirection: 'column',
        height: '100vh'
      }}>
        {/* Graph Canvas - 90% of graph section */}
        <Box sx={{ 
          flexGrow: 1, 
          position: 'relative', 
          height: '90%' 
        }} ref={containerRef}>
          
          {/* Error State */}
          {error && (
            <Box sx={{ 
              position: 'absolute', 
              top: 80, 
              left: 16, 
              right: 16, 
              zIndex: 1000 
            }}>
              <Alert severity="error" sx={{ 
                bgcolor: 'rgba(239, 68, 68, 0.1)', 
                color: '#ef4444',
                border: '1px solid rgba(239, 68, 68, 0.3)'
              }}>
                {error}
              </Alert>
            </Box>
          )}

          {/* Loading Overlay */}
          {filterLoading && (
            <Box sx={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              bgcolor: 'rgba(15, 23, 42, 0.7)',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              zIndex: 1000,
              backdropFilter: 'blur(4px)'
            }}>
              <Box sx={{ textAlign: 'center' }}>
                <CircularProgress sx={{ color: '#6366f1', mb: 2 }} />
                <Typography sx={{ color: 'white' }}>
                  Applying hierarchical filters...
                </Typography>
              </Box>
            </Box>
          )}

          {/* ReactFlow Graph */}
          {hasData ? (
            <ReactFlow
              nodes={nodes}
              edges={edges}
              nodeTypes={STABLE_NODE_TYPES}
              edgeTypes={STABLE_EDGE_TYPES}
              onNodesChange={onNodesChange}
              onEdgesChange={onEdgesChange}
              onNodeClick={handleNodeClick}
              onEdgeClick={handleEdgeClick}
              onNodeMouseEnter={handleNodeMouseEnter}
              onNodeMouseLeave={handleNodeMouseLeave}
              onEdgeMouseEnter={handleEdgeMouseEnter}
              onEdgeMouseLeave={handleEdgeMouseLeave}
              onPaneClick={handlePaneClick}
              fitView
              panOnDrag
              zoomOnScroll
              proOptions={{ hideAttribution: true }}
              onlyRenderVisibleElements={false}
              minZoom={0.1}
              maxZoom={2}
              fitViewOptions={{ padding: 0.2 }}
              style={{ background: 'transparent' }}
            >
              <Background 
                color="rgba(255, 255, 255, 0.1)" 
                gap={16} 
                size={1}
                style={{ opacity: 0.3 }}
              />
              <MiniMap 
                pannable 
                zoomable 
                style={{
                  backgroundColor: 'rgba(15, 23, 42, 0.8)',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '8px',
                  display: 'none', // Hidden by default
                }}
                maskColor="rgba(15, 23, 42, 0.6)"
              />
              <Controls 
                showInteractive 
                style={{
                  backgroundColor: 'rgba(15, 23, 42, 0.8)',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '8px'
                }}
              />
            </ReactFlow>
          ) : (
            // Empty state
            <Box sx={{
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              alignItems: 'center',
              height: '100%',
              color: 'white'
            }}>
              <Typography variant="h6" sx={{ mb: 1, opacity: 0.8 }}>
                No Data Available
              </Typography>
              <Typography variant="body2" sx={{ opacity: 0.6 }}>
                Try adjusting your hierarchical filters or check your region selection
              </Typography>
            </Box>
          )}

          {/* Floating Stats Cards */}
          <StatsCards 
            nodes={nodes} 
            edges={edges} 
            showDebug={showDebug}
            setShowDebug={setShowDebug}
            isDarkTheme={isDarkTheme}
            setIsDarkTheme={setIsDarkTheme}
          />
          
          {/* Debug Data Display */}
          <DebugDataDisplay nodes={nodes} edges={edges} show={showDebug} />
          
          {/* Additional Status Info */}
          <Box sx={{
            position: 'absolute',
            bottom: 16,
            left: 16,
            bgcolor: 'rgba(15, 23, 42, 0.9)',
            backdropFilter: 'blur(20px)',
            border: '1px solid rgba(255, 255, 255, 0.1)',
            borderRadius: 2,
            px: 2,
            py: 1,
            display: 'flex',
            alignItems: 'center',
            gap: 2
          }}>
            <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)' }}>
              Region: <span style={{ color: '#10b981', fontWeight: 'bold' }}>{currentRegions.join(', ')}</span>
            </Typography>
            <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)' }}>
              •
            </Typography>
            <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)' }}>
              Nodes: <span style={{ color: '#6366f1', fontWeight: 'bold' }}>{nodeCount}</span>
            </Typography>
            <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)' }}>
              •
            </Typography>
            <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)' }}>
              Edges: <span style={{ color: '#6366f1', fontWeight: 'bold' }}>{edgeCount}</span>
            </Typography>
            <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)' }}>
              •
            </Typography>
            <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)' }}>
              Source: <span style={{ color: '#6366f1', fontWeight: 'bold' }}>Hierarchical API</span>
            </Typography>
          </Box>
        </Box>

        {/* Bottom Insights Panel - 10% of graph section */}
        <Box sx={{ 
          height: '10%', 
          borderTop: '1px solid rgba(255, 255, 255, 0.1)',
          bgcolor: 'rgba(15, 23, 42, 0.98)',
          backdropFilter: 'blur(20px)',
          display: 'flex',
          alignItems: 'center'
        }}>
          <InsightsPanel 
            selectedNode={selectedNode || hoveredNode}
            selectedEdge={selectedEdge || hoveredEdge}
            isHovered={!!(hoveredNode || hoveredEdge)}
          />
        </Box>
      </Box>

      {/* Right Panel - Filters and Chat */}
      <Drawer 
        variant="permanent" 
        anchor="right" 
        sx={{ 
          width: 320,
          '& .MuiDrawer-paper': {
            width: 320,
            bgcolor: 'rgba(15, 23, 42, 0.95)',
            backdropFilter: 'blur(20px)',
            border: 'none',
            borderLeft: '1px solid rgba(255, 255, 255, 0.1)',
            height: '100vh'
          }
        }}
      >
        <Box sx={{ width: 320, height: '100%', display: 'flex', flexDirection: 'column' }}>
          {/* Tab header with proper spacing */}
          <Box sx={{ 
            flexShrink: 0,
            borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
            bgcolor: 'rgba(15, 23, 42, 0.98)'
          }}>
            <Tabs 
              value={tabValue} 
              onChange={handleTabChange}
              sx={{ 
                minHeight: 56, // Fixed height for consistent spacing
                '& .MuiTab-root': { 
                  color: 'rgba(255, 255, 255, 0.7)',
                  minHeight: 56,
                  textTransform: 'none',
                  fontWeight: 'medium',
                  '&.Mui-selected': { 
                    color: '#6366f1',
                    fontWeight: 'bold'
                  }
                },
                '& .MuiTabs-indicator': { backgroundColor: '#6366f1' }
              }}
            >
              <Tab 
                icon={<ChatIcon />} 
                label="Chat" 
                iconPosition="start"
                sx={{ 
                  gap: 1,
                  px: 2
                }}
              />
              <Tab 
                icon={<FilterIcon />} 
                label={
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                     Filters
                    {filterLoading && (
                      <CircularProgress size={12} sx={{ color: '#6366f1' }} />
                    )}
                  </Box>
                }
                iconPosition="start"
                sx={{ 
                  gap: 1,
                  px: 2
                }}
              />
            </Tabs>
          </Box>
          
          {/* Tab content with proper height calculation */}
          <Box sx={{ 
            flexGrow: 1, 
            overflow: 'hidden',
            height: 'calc(100vh - 56px)' // Subtract tab header height
          }}>
            <GraphDataProvider value={{
              filterOptions,
              currentFilters,
              currentRegions,
              filterLoading,
              error,
              changeRegions,
              applyFilters,
              resetFilters,
              getAvailableRegions
            }}>
              {tabValue === 0 && (
                <Box sx={{ height: '100%', overflow: 'hidden' }}>
                  <ChatInterface />
                </Box>
              )}
              {tabValue === 1 && (
                <Box sx={{ height: '100%', overflow: 'hidden' }}>
                  <WorkingFiltersInterface />
                </Box>
              )}
            </GraphDataProvider>
          </Box>
        </Box>
      </Drawer>
    </Box>
  );
}

// Main wrapper component with ReactFlowProvider
export default function JPMGraphPreviewWithFilters() {
  return (
    <ReactFlowProvider>
      <GraphComponent />
    </ReactFlowProvider>
  );
}