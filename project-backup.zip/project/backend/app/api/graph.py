"""
Graph API endpoints for Smart Network Backend.
"""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from fastapi.responses import JSONResponse
from loguru import logger

from app.database.connection import Neo4jConnection, get_neo4j_connection
from app.database.models import (
    GraphResponse, FilterCriteria, DataGenerationConfig, DataGenerationResponse,
    DatabaseStats, CypherQueryRequest, CypherQueryResponse, ErrorResponse
)
from app.services.graph_service import GraphService
from app.services.data_generator import SmartNetworkDataGenerator

# Create router
graph_router = APIRouter()


@graph_router.get(
    "/region/{region}",
    response_model=GraphResponse,
    summary="Get graph data for a specific region",
    description="Retrieve all nodes and relationships for a specific region (NAI, EMEA, APAC)"
)
async def get_region_data(
    region: str,
    connection: Neo4jConnection = Depends(get_neo4j_connection)
):
    """Get graph data for a specific region."""
    try:
        logger.info(f"🌍 Getting graph data for region: {region}")
        
        if region.upper() not in ["NAI", "EMEA", "APAC"]:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid region: {region}. Must be one of: NAI, EMEA, APAC"
            )
        print('failed')
        graph_service = GraphService(connection)
        result = await graph_service.get_region_data1([region.upper()])
        
        
        logger.success(f"✅ Retrieved {len(result.nodes)} nodes and {len(result.relationships)} relationships for {region}")
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Failed to get region data for {region}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@graph_router.post(
    "/filter",
    response_model=GraphResponse,
    summary="Get filtered graph data",
    description="Apply filters to retrieve specific subsets of the graph data"
)
async def get_filtered_data(
    filters: FilterCriteria,
    connection: Neo4jConnection = Depends(get_neo4j_connection)
):
    """Get graph data with applied filters."""
    try:
        logger.info(f"🔍 Applying filters: {filters.dict(exclude_none=True)}")
        
        graph_service = GraphService(connection)
        result = await graph_service.get_filtered_data(filters)
        
        logger.success(f"✅ Filtered data: {len(result.nodes)} nodes, {len(result.relationships)} relationships")
        
        return result
        
    except Exception as e:
        logger.error(f"❌ Failed to get filtered data: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@graph_router.get(
    "/stats",
    response_model=DatabaseStats,
    summary="Get database statistics",
    description="Retrieve comprehensive statistics about the current database state"
)
async def get_database_statistics(
    connection: Neo4jConnection = Depends(get_neo4j_connection)
):
    """Get comprehensive database statistics."""
    try:
        logger.info("📊 Getting database statistics")
        
        graph_service = GraphService(connection)
        stats = await graph_service.get_database_statistics()
        
        return stats
        
    except Exception as e:
        logger.error(f"❌ Failed to get database statistics: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@graph_router.post(
    "/generate",
    response_model=DataGenerationResponse,
    summary="Generate sample dataset",
    description="Generate a large, realistic dataset based on configuration parameters"
)
async def generate_dataset(
    config: DataGenerationConfig,
    background_tasks: BackgroundTasks,
    connection: Neo4jConnection = Depends(get_neo4j_connection)
):
    """Generate a large sample dataset."""
    try:
        logger.info(f"🏭 Starting dataset generation with config: {config.dict()}")
        
        # Validate configuration
        total_nodes = (
            len(config.regions) * config.consultants_per_region * 
            (1 + config.field_consultants_per_consultant + 
             config.field_consultants_per_consultant * config.companies_per_field_consultant +
             config.field_consultants_per_consultant * config.companies_per_field_consultant * config.products_per_company)
        )
        
        if total_nodes > 50000:  # Safety limit
            raise HTTPException(
                status_code=400,
                detail=f"Configuration would generate {total_nodes} nodes, which exceeds the limit of 50,000"
            )
        
        generator = SmartNetworkDataGenerator(connection)
        result = await generator.generate_large_dataset(config)
        
        logger.success(f"✅ Dataset generation completed: {result.created_counts}")
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Dataset generation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@graph_router.delete(
    "/clear",
    summary="Clear all data",
    description="⚠️ WARNING: This will delete ALL data in the database"
)
async def clear_database(
    connection: Neo4jConnection = Depends(get_neo4j_connection)
):
    """Clear all data from the database."""
    try:
        logger.warning("🗑️ Clearing all database data")
        
        query = "MATCH (n) DETACH DELETE n"
        result = await connection.execute_write_query(query)
        
        logger.success(f"✅ Database cleared: {result.get('nodes_deleted', 0)} nodes deleted")
        
        return {
            "success": True,
            "message": "Database cleared successfully",
            "nodes_deleted": result.get("nodes_deleted", 0),
            "relationships_deleted": result.get("relationships_deleted", 0)
        }
        
    except Exception as e:
        logger.error(f"❌ Failed to clear database: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@graph_router.post(
    "/query",
    response_model=CypherQueryResponse,
    summary="Execute custom Cypher query",
    description="Execute a custom Cypher query (read-only by default for safety)"
)
async def execute_cypher_query(
    query_request: CypherQueryRequest,
    connection: Neo4jConnection = Depends(get_neo4j_connection)
):
    """Execute a custom Cypher query."""
    try:
        logger.info(f"🔍 Executing Cypher query: {query_request.query[:100]}...")
        
        if query_request.read_only:
            result_data = await connection.execute_query(
                query_request.query,
                query_request.parameters
            )
        else:
            # For write queries, use execute_write_query
            result_data = await connection.execute_write_query(
                query_request.query,
                query_request.parameters
            )
            # Convert write result to list format
            result_data = [result_data] if isinstance(result_data, dict) else result_data
        
        return CypherQueryResponse(
            success=True,
            data=result_data,
            execution_time=0.0,  # Would need to measure this properly
            query=query_request.query,
            row_count=len(result_data) if isinstance(result_data, list) else 0
        )
        
    except Exception as e:
        logger.error(f"❌ Cypher query failed: {e}")
        return CypherQueryResponse(
            success=False,
            data=[],
            execution_time=0.0,
            query=query_request.query,
            row_count=0,
            error=str(e)
        )


@graph_router.get(
    "/nodes/{node_id}",
    summary="Get node details",
    description="Get detailed information about a specific node by ID"
)
async def get_node_details(
    node_id: str,
    connection: Neo4jConnection = Depends(get_neo4j_connection)
):
    """Get detailed information about a specific node."""
    try:
        logger.info(f"🔍 Getting details for node: {node_id}")
        
        query = """
        MATCH (n {id: $node_id})
        OPTIONAL MATCH (n)-[r]->(connected)
        RETURN n, 
               collect(DISTINCT {
                   relationship: r,
                   connected_node: connected
               }) as connections
        """
        
        result = await connection.execute_query(query, {"node_id": node_id})
        
        if not result:
            raise HTTPException(status_code=404, detail=f"Node {node_id} not found")
        
        node_data = result[0]
        
        return {
            "node": node_data["n"],
            "connections": node_data["connections"],
            "connection_count": len([c for c in node_data["connections"] if c["relationship"]])
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Failed to get node details for {node_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@graph_router.get(
    "/relationships/{rel_id}",
    summary="Get relationship details",
    description="Get detailed information about a specific relationship by ID"
)
async def get_relationship_details(
    rel_id: str,
    connection: Neo4jConnection = Depends(get_neo4j_connection)
):
    """Get detailed information about a specific relationship."""
    try:
        logger.info(f"🔍 Getting details for relationship: {rel_id}")
        
        query = """
        MATCH (source)-[r]->(target)
        WHERE id(r) = toInteger($rel_id)
        RETURN r, source, target
        """
        
        result = await connection.execute_query(query, {"rel_id": rel_id})
        
        if not result:
            raise HTTPException(status_code=404, detail=f"Relationship {rel_id} not found")
        
        rel_data = result[0]
        
        return {
            "relationship": rel_data["r"],
            "source_node": rel_data["source"],
            "target_node": rel_data["target"]
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Failed to get relationship details for {rel_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))