"""
Filters API router for Smart Network Backend.
Handles filter options, validation, and filter-based graph queries.
"""
from typing import Dict, List, Any, Optional
from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import JSONResponse

from app.database.models import (
    FilterCriteria, FilterOptions, GraphResponse, ErrorResponse,
    DatabaseStats, RegionStats
)
from app.services.graph_service import graph_service
from app.config import REGIONS, SALES_REGIONS, CHANNELS, ASSET_CLASSES, PRIVACY_LEVELS

# Create the filters router
filters_router = APIRouter(
    prefix="/api/v1/filters",
    tags=["filters"],
    responses={
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse}
    }
)


@filters_router.get("/options", response_model=FilterOptions)
def get_filter_options():
    """
    Get all available filter options from the database.
    Returns unique values for each filterable field.
    """
    try:
        options = graph_service.get_filter_options()
        
        return FilterOptions(
            regions=options.get("regions", REGIONS),
            sales_regions=options.get("sales_regions", SALES_REGIONS),
            channels=options.get("channels", CHANNELS),
            asset_classes=options.get("asset_classes", ASSET_CLASSES),
            consultants=options.get("consultants", []),
            field_consultants=options.get("field_consultants", []),
            companies=options.get("companies", []),
            products=options.get("products", []),
            incumbent_products=options.get("incumbent_products", []),
            pcas=options.get("pcas", []),
            acas=options.get("acas", []),
            rankgroups=options.get("rankgroups", []),
            mandate_statuses=options.get("mandate_statuses", []),
            jpm_flags=options.get("jpm_flags", []),
            privacy_levels=options.get("privacy_levels", PRIVACY_LEVELS)
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get filter options: {str(e)}")


@filters_router.post("/apply", response_model=GraphResponse)
def apply_filters(filter_criteria: FilterCriteria):
    """
    Apply filter criteria and return filtered graph data.
    """
    try:
        # Convert Pydantic model to dict for the service
        filters_dict = filter_criteria.dict(exclude_unset=True)
        
        # Get filtered graph data
        graph_data = graph_service.get_filtered_graph(filters_dict)
        
        return GraphResponse(
            nodes=graph_data["nodes"],
            relationships=graph_data["relationships"],
            metadata=graph_data.get("metadata", {})
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to apply filters: {str(e)}")


@filters_router.get("/validate")
def validate_filters(
    regions: Optional[List[str]] = Query(None),
    sales_regions: Optional[List[str]] = Query(None),
    channels: Optional[List[str]] = Query(None),
    node_types: Optional[List[str]] = Query(None),
    asset_classes: Optional[List[str]] = Query(None),
    privacy_levels: Optional[List[str]] = Query(None)
):
    """
    Validate filter values against available options.
    Returns validation results and suggestions.
    """
    try:
        # Get available options
        available_options = graph_service.get_filter_options()
        
        validation_results = {
            "valid": True,
            "errors": [],
            "warnings": [],
            "suggestions": {}
        }
        
        # Validate regions
        if regions:
            invalid_regions = [r for r in regions if r not in available_options.get("regions", REGIONS)]
            if invalid_regions:
                validation_results["valid"] = False
                validation_results["errors"].append(f"Invalid regions: {invalid_regions}")
                validation_results["suggestions"]["regions"] = available_options.get("regions", REGIONS)
        
        # Validate sales regions
        if sales_regions:
            invalid_sales_regions = [sr for sr in sales_regions if sr not in available_options.get("sales_regions", SALES_REGIONS)]
            if invalid_sales_regions:
                validation_results["valid"] = False
                validation_results["errors"].append(f"Invalid sales regions: {invalid_sales_regions}")
                validation_results["suggestions"]["sales_regions"] = available_options.get("sales_regions", SALES_REGIONS)
        
        # Validate channels
        if channels:
            invalid_channels = [c for c in channels if c not in available_options.get("channels", CHANNELS)]
            if invalid_channels:
                validation_results["valid"] = False
                validation_results["errors"].append(f"Invalid channels: {invalid_channels}")
                validation_results["suggestions"]["channels"] = available_options.get("channels", CHANNELS)
        
        # Validate node types
        if node_types:
            valid_node_types = ["CONSULTANT", "FIELD_CONSULTANT", "COMPANY", "PRODUCT", "INCUMBENT_PRODUCT"]
            invalid_node_types = [nt for nt in node_types if nt not in valid_node_types]
            if invalid_node_types:
                validation_results["valid"] = False
                validation_results["errors"].append(f"Invalid node types: {invalid_node_types}")
                validation_results["suggestions"]["node_types"] = valid_node_types
        
        # Validate asset classes
        if asset_classes:
            invalid_asset_classes = [ac for ac in asset_classes if ac not in available_options.get("asset_classes", ASSET_CLASSES)]
            if invalid_asset_classes:
                validation_results["valid"] = False
                validation_results["errors"].append(f"Invalid asset classes: {invalid_asset_classes}")
                validation_results["suggestions"]["asset_classes"] = available_options.get("asset_classes", ASSET_CLASSES)
        
        # Validate privacy levels
        if privacy_levels:
            invalid_privacy_levels = [pl for pl in privacy_levels if pl not in available_options.get("privacy_levels", PRIVACY_LEVELS)]
            if invalid_privacy_levels:
                validation_results["valid"] = False
                validation_results["errors"].append(f"Invalid privacy levels: {invalid_privacy_levels}")
                validation_results["suggestions"]["privacy_levels"] = available_options.get("privacy_levels", PRIVACY_LEVELS)
        
        return validation_results
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to validate filters: {str(e)}")


@filters_router.get("/region/{region}/options")
def get_region_filter_options(region: str):
    """
    Get filter options specific to a region.
    """
    try:
        region = region.upper()
        if region not in REGIONS:
            raise HTTPException(status_code=400, detail=f"Invalid region: {region}")
        
        # Get region-specific filter options using graph service
        with graph_service.driver.session() as session:
            # Get unique values for this region
            queries = {
                "sales_regions": f"MATCH (n {{region: '{region}'}}) WHERE n.sales_region IS NOT NULL RETURN DISTINCT n.sales_region as value ORDER BY value",
                "channels": f"MATCH (n {{region: '{region}'}}) WHERE n.channel IS NOT NULL RETURN DISTINCT n.channel as value ORDER BY value",
                "asset_classes": f"MATCH (n {{region: '{region}'}}) WHERE n.asset_class IS NOT NULL RETURN DISTINCT n.asset_class as value ORDER BY value",
                "pcas": f"MATCH (n {{region: '{region}'}}) WHERE n.pca IS NOT NULL RETURN DISTINCT n.pca as value ORDER BY value",
                "acas": f"MATCH (n {{region: '{region}'}}) WHERE n.aca IS NOT NULL RETURN DISTINCT n.aca as value ORDER BY value",
                "privacy_levels": f"MATCH (n {{region: '{region}'}}) WHERE n.privacy IS NOT NULL RETURN DISTINCT n.privacy as value ORDER BY value",
                "jpm_flags": f"MATCH (n {{region: '{region}'}}) WHERE n.jpm_flag IS NOT NULL RETURN DISTINCT n.jpm_flag as value ORDER BY value"
            }
            
            region_options = {}
            for key, query in queries.items():
                result = session.run(query)
                region_options[key] = [record["value"] for record in result]
            
            # Get entity lists
            entity_queries = {
                "consultants": f"MATCH (c:CONSULTANT {{region: '{region}'}}) RETURN c.id as id, c.name as name ORDER BY c.name",
                "field_consultants": f"MATCH (fc:FIELD_CONSULTANT {{region: '{region}'}}) RETURN fc.id as id, fc.name as name ORDER BY fc.name",
                "companies": f"MATCH (comp:COMPANY {{region: '{region}'}}) RETURN comp.id as id, comp.name as name ORDER BY comp.name",
                "products": f"MATCH (p:PRODUCT {{region: '{region}'}}) RETURN p.id as id, p.name as name ORDER BY p.name",
                "incumbent_products": f"MATCH (ip:INCUMBENT_PRODUCT {{region: '{region}'}}) RETURN ip.id as id, ip.name as name ORDER BY ip.name"
            }
            
            for key, query in entity_queries.items():
                result = session.run(query)
                region_options[key] = [{"id": record["id"], "name": record["name"]} for record in result]
        
        return {
            "region": region,
            "options": region_options
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get region filter options: {str(e)}")


@filters_router.get("/combinations")
def get_filter_combinations():
    """
    Get common filter combinations and their result counts.
    Useful for suggesting popular filter presets.
    """
    try:
        combinations = []
        
        # Get combinations for each region
        for region in REGIONS:
            region_stats = graph_service.get_region_stats(region)
            
            combinations.append({
                "name": f"All {region} Data",
                "description": f"Complete graph for {region} region",
                "filters": {"regions": [region]},
                "estimated_count": region_stats.get("total_nodes", 0)
            })
            
            # Add asset class combinations for this region
            with graph_service.driver.session() as session:
                asset_classes_result = session.run(f"""
                    MATCH (n {{region: '{region}'}})
                    WHERE n.asset_class IS NOT NULL
                    RETURN n.asset_class as asset_class, count(n) as count
                    ORDER BY count DESC
                    LIMIT 3
                """)
                
                for record in asset_classes_result:
                    combinations.append({
                        "name": f"{region} {record['asset_class']} Focus",
                        "description": f"{record['asset_class']} products and related entities in {region}",
                        "filters": {
                            "regions": [region],
                            "asset_classes": [record["asset_class"]]
                        },
                        "estimated_count": record["count"]
                    })
        
        # Add cross-regional combinations
        combinations.extend([
            {
                "name": "Global Consultants",
                "description": "All consultants across all regions",
                "filters": {"node_types": ["CONSULTANT"]},
                "estimated_count": sum([
                    graph_service.get_region_stats(r).get("node_counts", {}).get("CONSULTANT", 0) 
                    for r in REGIONS
                ])
            },
            {
                "name": "All Products",
                "description": "All products and incumbent products",
                "filters": {"node_types": ["PRODUCT", "INCUMBENT_PRODUCT"]},
                "estimated_count": sum([
                    graph_service.get_region_stats(r).get("node_counts", {}).get("PRODUCT", 0) + 
                    graph_service.get_region_stats(r).get("node_counts", {}).get("INCUMBENT_PRODUCT", 0) 
                    for r in REGIONS
                ])
            }
        ])
        
        # Sort by estimated count descending
        combinations.sort(key=lambda x: x["estimated_count"], reverse=True)
        
        return {
            "combinations": combinations[:20],  # Return top 20
            "total_available": len(combinations)
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get filter combinations: {str(e)}")


@filters_router.post("/count")
def count_filtered_results(filter_criteria: FilterCriteria):
    """
    Get count of nodes and relationships that would be returned by the filters
    without actually returning the data. Useful for UI pagination and performance.
    """
    try:
        # Convert Pydantic model to dict
        filters_dict = filter_criteria.dict(exclude_unset=True)
        
        with graph_service.driver.session() as session:
            # Build WHERE clause for nodes
            where_clauses = []
            params = {}
            
            if filters_dict.get("regions"):
                where_clauses.append("n.region IN $regions")
                params["regions"] = filters_dict["regions"]
            
            if filters_dict.get("node_types"):
                node_labels = " OR ".join([f"n:{label}" for label in filters_dict["node_types"]])
                where_clauses.append(f"({node_labels})")
            
            if filters_dict.get("sales_regions"):
                where_clauses.append("n.sales_region IN $sales_regions")
                params["sales_regions"] = filters_dict["sales_regions"]
            
            if filters_dict.get("channels"):
                where_clauses.append("n.channel IN $channels")
                params["channels"] = filters_dict["channels"]
            
            if filters_dict.get("asset_classes"):
                where_clauses.append("n.asset_class IN $asset_classes")
                params["asset_classes"] = filters_dict["asset_classes"]
            
            if filters_dict.get("privacy_levels"):
                where_clauses.append("n.privacy IN $privacy_levels")
                params["privacy_levels"] = filters_dict["privacy_levels"]
            
            where_clause = " AND ".join(where_clauses) if where_clauses else "TRUE"
            
            # Count nodes
            nodes_query = f"""
            MATCH (n)
            WHERE {where_clause}
            RETURN count(n) as node_count
            """
            
            node_count = session.run(nodes_query, params).single()["node_count"]
            
            # Count relationships between filtered nodes
            if node_count > 0:
                # Get node IDs first
                ids_query = f"""
                MATCH (n)
                WHERE {where_clause}
                RETURN id(n) as node_id
                """
                
                node_ids = [record["node_id"] for record in session.run(ids_query, params)]
                
                # Count relationships
                rels_query = """
                MATCH (source)-[r]->(target)
                WHERE id(source) IN $node_ids AND id(target) IN $node_ids
                RETURN count(r) as rel_count
                """
                
                rel_count = session.run(rels_query, {"node_ids": node_ids}).single()["rel_count"]
            else:
                rel_count = 0
        
        return {
            "filters_applied": filters_dict,
            "node_count": node_count,
            "relationship_count": rel_count,
            "total_elements": node_count + rel_count
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to count filtered results: {str(e)}")


@filters_router.delete("/clear")
def clear_filters():
    """
    Return default filter criteria (essentially clearing all filters).
    """
    return FilterCriteria()


@filters_router.get("/presets")
def get_filter_presets():
    """
    Get predefined filter presets for common use cases.
    """
    presets = [
        {
            "id": "all_nai",
            "name": "North America",
            "description": "All data for North America region",
            "filters": FilterCriteria(regions=["NAI"]).dict()
        },
        {
            "id": "all_emea",
            "name": "EMEA",
            "description": "All data for Europe, Middle East & Africa",
            "filters": FilterCriteria(regions=["EMEA"]).dict()
        },
        {
            "id": "all_apac",
            "name": "APAC",
            "description": "All data for Asia Pacific region",
            "filters": FilterCriteria(regions=["APAC"]).dict()
        },
        {
            "id": "consultants_only",
            "name": "Consultants Only",
            "description": "Show only consultant and field consultant nodes",
            "filters": FilterCriteria(node_types=["CONSULTANT", "FIELD_CONSULTANT"]).dict()
        },
        {
            "id": "products_only",
            "name": "Products Only",
            "description": "Show only product and incumbent product nodes",
            "filters": FilterCriteria(node_types=["PRODUCT", "INCUMBENT_PRODUCT"]).dict()
        },
        {
            "id": "equities_focus",
            "name": "Equities Focus",
            "description": "Focus on equities asset class",
            "filters": FilterCriteria(asset_classes=["Equities"]).dict()
        },
        {
            "id": "fixed_income_focus",
            "name": "Fixed Income Focus", 
            "description": "Focus on fixed income asset class",
            "filters": FilterCriteria(asset_classes=["Fixed Income"]).dict()
        },
        {
            "id": "high_activity",
            "name": "High Activity",
            "description": "Companies and products with active mandates",
            "filters": FilterCriteria(
                node_types=["COMPANY", "PRODUCT", "INCUMBENT_PRODUCT"],
                mandate_statuses=["Active"]
            ).dict()
        }
    ]
    
    return {
        "presets": presets,
        "total_count": len(presets)
    }