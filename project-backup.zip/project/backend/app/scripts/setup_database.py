#!/usr/bin/env python3
"""
FIXED: Complete setup script for Neo4j database with proper nodes, relationships, and sample data.
This creates everything you need based on your schema with correct relationships.
"""
import asyncio
import random
import sys
from pathlib import Path
from datetime import datetime, timedelta

# Add the app directory to the Python path
sys.path.insert(0, str(Path(__file__).parent))

from neo4j import GraphDatabase
from faker import Faker

# Your Neo4j connection details - UPDATE THESE!
NEO4J_URI = "bolt://localhost:7687"  # ✅ FIXED: Use bolt:// not neo4j://
NEO4J_USERNAME = "neo4j"
NEO4J_PASSWORD = "test1234"  # ✅ UPDATE: Replace with your actual password
NEO4J_DATABASE = "neo4j"  # ✅ FIXED: Use default "neo4j" database

fake = Faker()
Faker.seed(42)
random.seed(42)

class SmartNetworkSetup:
    """Complete setup for Smart Network Neo4j database."""
    
    def __init__(self):
        self.driver = GraphDatabase.driver(
            NEO4J_URI,
            auth=(NEO4J_USERNAME, NEO4J_PASSWORD)
        )
        
        # Data configuration
        self.regions = ["NAI", "EMEA", "APAC"]
        self.sales_regions = ["East", "West", "Central", "International"]
        self.channels = ["Consultant Sales", "North Americas Institutional DC", "Asia Institutional", "Beta Strategies"]
        self.asset_classes = ["Equities", "Fixed Income", "Real Estate", "Commodities", "Alternatives"]
        self.privacy_levels = ["Public", "Private", "Confidential"]
        self.mandate_statuses = ["Active", "At Risk", "Conversion in Progress"]  # ✅ FIXED: Only 3 statuses
        self.rankgroups = ["Positive", "Negative", "Neutral", "Introduced"]
        self.jpm_flags = ["Y", "N"]
        
        # Company name prefixes by region
        self.company_prefixes = {
            "NAI": ["American", "North", "US", "Capital", "Liberty"],
            "EMEA": ["European", "Euro", "British", "Continental", "Royal"],
            "APAC": ["Asia", "Pacific", "Eastern", "Dragon", "Rising"]
        }
    
    def close(self):
        """Close database connection."""
        if self.driver:
            self.driver.close()
    
    def test_connection(self):
        """Test database connection."""
        try:
            with self.driver.session() as session:
                result = session.run("RETURN 1 as test")
                test_value = result.single()["test"]
                print(f"✅ Database connection successful (test value: {test_value})")
                return True
        except Exception as e:
            print(f"❌ Database connection failed: {e}")
            return False
    
    def clear_database(self):
        """Clear all existing data."""
        print("🧹 Clearing existing database data...")
        
        with self.driver.session() as session:
            result = session.run("MATCH (n) DETACH DELETE n")
            summary = result.consume()
            print(f"✅ Cleared {summary.counters.nodes_deleted} nodes and {summary.counters.relationships_deleted} relationships")
    
    def create_constraints_and_indexes(self):
        """Create database constraints and indexes."""
        print("📋 Creating constraints and indexes...")
        
        constraints_and_indexes = [
            # Constraints
            "CREATE CONSTRAINT consultant_id_unique IF NOT EXISTS FOR (c:CONSULTANT) REQUIRE c.id IS UNIQUE",
            "CREATE CONSTRAINT field_consultant_id_unique IF NOT EXISTS FOR (fc:FIELD_CONSULTANT) REQUIRE fc.id IS UNIQUE",
            "CREATE CONSTRAINT company_id_unique IF NOT EXISTS FOR (comp:COMPANY) REQUIRE comp.id IS UNIQUE",
            "CREATE CONSTRAINT product_id_unique IF NOT EXISTS FOR (p:PRODUCT) REQUIRE p.id IS UNIQUE",
            
            # Indexes for performance
            "CREATE INDEX consultant_region_idx IF NOT EXISTS FOR (c:CONSULTANT) ON (c.region)",
            "CREATE INDEX field_consultant_region_idx IF NOT EXISTS FOR (fc:FIELD_CONSULTANT) ON (fc.region)",
            "CREATE INDEX company_region_idx IF NOT EXISTS FOR (comp:COMPANY) ON (comp.region)",
            "CREATE INDEX product_region_idx IF NOT EXISTS FOR (p:PRODUCT) ON (p.region)",
        ]
        
        with self.driver.session() as session:
            for query in constraints_and_indexes:
                try:
                    session.run(query)
                    constraint_name = query.split()[2] if "CONSTRAINT" in query else query.split()[2]
                    print(f"  ✅ Created: {constraint_name}")
                except Exception as e:
                    if "already exists" in str(e).lower():
                        print(f"  ⚠️ Already exists: {constraint_name}")
                    else:
                        print(f"  ❌ Failed: {e}")
    
    def generate_sample_data(self):
        """Generate sample data with proper relationships."""
        print("🏭 Generating sample data...")
        
        # ✅ FIXED: Reduced configuration for better connectivity
        consultants_per_region = 2
        field_consultants_per_consultant = 2
        companies_per_field_consultant = 1  # ✅ FIXED: 1:1 ratio for guaranteed connections
        products_per_company = 2
        
        all_nodes = {
            'consultants': [],
            'field_consultants': [],
            'companies': [],
            'products': []
        }
        
        # Generate data for each region
        for region in self.regions:
            print(f"  🌍 Generating data for {region}...")
            
            # 1. Create consultants
            region_consultants = []
            for i in range(consultants_per_region):
                consultant_id = f"{region}_C{i+1}"
                consultant = {
                    "id": consultant_id,
                    "name": f"{fake.first_name()} {fake.last_name()} (Consultant)",
                    "region": region,
                    "pca": f"PCA_{region}_{i+1}",
                    "sales_region": random.choice(self.sales_regions),
                    "channel": random.choice(self.channels)
                }
                region_consultants.append(consultant)
                all_nodes['consultants'].append(consultant)
            
            # 2. Create field consultants (linked to consultants)
            region_field_consultants = []
            for consultant in region_consultants:
                for j in range(field_consultants_per_consultant):
                    fc_id = f"{region}_F{consultant['id'].split('_')[-1]}_{j+1}"
                    field_consultant = {
                        "id": fc_id,
                        "name": f"{fake.first_name()} {fake.last_name()} (Field)",
                        "region": region,
                        "parentConsultantId": consultant["id"]  # ✅ FIXED: Proper parent reference
                    }
                    region_field_consultants.append(field_consultant)
                    all_nodes['field_consultants'].append(field_consultant)
            
            # 3. Create companies (one per field consultant for guaranteed connection)
            region_companies = []
            for i, field_consultant in enumerate(region_field_consultants):
                company_id = f"{region}_CO{i+1}"
                prefix = random.choice(self.company_prefixes.get(region, ["Global"]))
                company = {
                    "id": company_id,
                    "name": f"{prefix} {fake.company().split()[0]} Corp",
                    "region": region,
                    "pca": f"PCA_{region}_{random.randint(1, len(region_consultants))}",
                    "aca": f"ACA_{region}_{random.randint(1, len(region_consultants))}",
                    "sales_region": random.choice(self.sales_regions),
                    "channel": random.choice(self.channels),
                    "privacy": random.choice(self.privacy_levels),
                    # ✅ FIXED: Link to specific field consultant
                    "covered_by_field_consultant": field_consultant["id"]
                }
                region_companies.append(company)
                all_nodes['companies'].append(company)
            
            # 4. Create products (linked to companies)
            for company in region_companies:
                for i in range(products_per_company):
                    product_id = f"{region}_P{company['id'].split('_')[-1]}_{i+1}"
                    asset_class = random.choice(self.asset_classes)
                    product = {
                        "id": product_id,
                        "name": f"{region} {asset_class} Fund {i+1}",
                        "region": region,
                        "asset_class": asset_class,
                        "product_label": f"{region}_PROD_{i+1}",
                        "jpm_flag": random.choice(self.jpm_flags),
                        # ✅ FIXED: Link to owning company
                        "owned_by_company": company["id"]
                    }
                    all_nodes['products'].append(product)
        
        # ✅ FIXED: Insert all nodes first
        self._insert_nodes("CONSULTANT", all_nodes['consultants'])
        self._insert_nodes("FIELD_CONSULTANT", all_nodes['field_consultants'])
        self._insert_nodes("COMPANY", all_nodes['companies'])
        self._insert_nodes("PRODUCT", all_nodes['products'])
        
        # ✅ FIXED: Create relationships with guaranteed connections
        self._create_relationships_fixed(all_nodes)
        
        print(f"✅ Generated {len(all_nodes['consultants'])} consultants, {len(all_nodes['field_consultants'])} field consultants")
        print(f"✅ Generated {len(all_nodes['companies'])} companies, {len(all_nodes['products'])} products")
    
    def _insert_nodes(self, node_type, nodes):
        """Insert nodes of a specific type."""
        if not nodes:
            return
            
        print(f"  📊 Creating {len(nodes)} {node_type} nodes...")
        
        query = f"""
        UNWIND $nodes AS node
        CREATE (n:{node_type})
        SET n = node
        """
        
        with self.driver.session() as session:
            result = session.run(query, {"nodes": nodes})
            summary = result.consume()
            print(f"    ✅ Created {summary.counters.nodes_created} {node_type} nodes")
    
    def _create_relationships_fixed(self, all_nodes):
        """Create all relationships with guaranteed connections."""
        print("🔗 Creating relationships...")
        
        # 1. ✅ EMPLOYS relationships (Consultant -> Field Consultant)
        employs_rels = []
        for fc in all_nodes['field_consultants']:
            if fc.get("parentConsultantId"):
                employs_rels.append({
                    "consultant_id": fc["parentConsultantId"],
                    "field_consultant_id": fc["id"]
                })
        
        with self.driver.session() as session:
            result = session.run("""
                UNWIND $rels AS rel
                MATCH (c:CONSULTANT {id: rel.consultant_id})
                MATCH (fc:FIELD_CONSULTANT {id: rel.field_consultant_id})
                CREATE (c)-[:EMPLOYS {sourceId: rel.consultant_id, targetId: rel.field_consultant_id}]->(fc)
            """, {"rels": employs_rels})
            summary = result.consume()
            print(f"  ✅ Created {summary.counters.relationships_created} EMPLOYS relationships")
        
        # 2. ✅ COVERS relationships (Field Consultant -> Company)
        covers_rels = []
        for company in all_nodes['companies']:
            if company.get("covered_by_field_consultant"):
                covers_rels.append({
                    "field_consultant_id": company["covered_by_field_consultant"],
                    "company_id": company["id"],
                    "levelOfInfluence": random.randint(1, 4)  # ✅ FIXED: Proper influence levels
                })
        
        with self.driver.session() as session:
            result = session.run("""
                UNWIND $rels AS rel
                MATCH (fc:FIELD_CONSULTANT {id: rel.field_consultant_id})
                MATCH (c:COMPANY {id: rel.company_id})
                CREATE (fc)-[:COVERS {
                    sourceId: rel.field_consultant_id, 
                    targetId: rel.company_id,
                    levelOfInfluence: rel.levelOfInfluence
                }]->(c)
            """, {"rels": covers_rels})
            summary = result.consume()
            print(f"  ✅ Created {summary.counters.relationships_created} COVERS relationships")
        
        # 3. ✅ OWNS relationships (Company -> Product)
        owns_rels = []
        for product in all_nodes['products']:
            if product.get("owned_by_company"):
                owns_rels.append({
                    "company_id": product["owned_by_company"],
                    "product_id": product["id"],
                    "mandateStatus": random.choice(self.mandate_statuses),  # ✅ FIXED: Property name
                    "consultant": random.choice([c["id"] for c in all_nodes['consultants'] if c["region"] == product["region"]]),
                    "manager": f"Manager_{fake.last_name()}",
                    "commitment_market_value": random.randint(100000, 10000000)
                })
        
        with self.driver.session() as session:
            result = session.run("""
                UNWIND $rels AS rel
                MATCH (c:COMPANY {id: rel.company_id})
                MATCH (p:PRODUCT {id: rel.product_id})
                CREATE (c)-[:OWNS {
                    sourceId: rel.company_id,
                    targetId: rel.product_id,
                    mandateStatus: rel.mandateStatus,
                    consultant: rel.consultant,
                    manager: rel.manager,
                    commitment_market_value: rel.commitment_market_value
                }]->(p)
            """, {"rels": owns_rels})
            summary = result.consume()
            print(f"  ✅ Created {summary.counters.relationships_created} OWNS relationships")
        
        # 4. ✅ RATES relationships (Consultant -> Product)
        rates_rels = []
        for consultant in all_nodes['consultants']:
            # Each consultant rates 2-3 products from their region
            region_products = [p for p in all_nodes['products'] if p["region"] == consultant["region"]]
            num_ratings = min(3, len(region_products))
            products_to_rate = random.sample(region_products, num_ratings)
            
            for product in products_to_rate:
                rates_rels.append({
                    "consultant_id": consultant["id"],
                    "product_id": product["id"],
                    "rankgroup": random.choice(self.rankgroups),
                    "influencedConsultant": consultant["id"]
                })
        
        with self.driver.session() as session:
            result = session.run("""
                UNWIND $rels AS rel
                MATCH (c:CONSULTANT {id: rel.consultant_id})
                MATCH (p:PRODUCT {id: rel.product_id})
                CREATE (c)-[:RATES {
                    sourceId: rel.consultant_id,
                    targetId: rel.product_id,
                    rankgroup: rel.rankgroup,
                    influencedConsultant: rel.influencedConsultant
                }]->(p)
            """, {"rels": rates_rels})
            summary = result.consume()
            print(f"  ✅ Created {summary.counters.relationships_created} RATES relationships")
    
    def verify_setup(self):
        """Verify the database setup."""
        print("🔍 Verifying database setup...")
        
        verification_queries = {
            "Total Nodes": "MATCH (n) RETURN count(n) as count",
            "Total Relationships": "MATCH ()-[r]->() RETURN count(r) as count",
            "Consultants": "MATCH (c:CONSULTANT) RETURN count(c) as count",
            "Field Consultants": "MATCH (fc:FIELD_CONSULTANT) RETURN count(fc) as count", 
            "Companies": "MATCH (comp:COMPANY) RETURN count(comp) as count",
            "Products": "MATCH (p:PRODUCT) RETURN count(p) as count",
            "EMPLOYS": "MATCH ()-[r:EMPLOYS]->() RETURN count(r) as count",
            "COVERS": "MATCH ()-[r:COVERS]->() RETURN count(r) as count",
            "OWNS": "MATCH ()-[r:OWNS]->() RETURN count(r) as count",
            "RATES": "MATCH ()-[r:RATES]->() RETURN count(r) as count"
        }
        
        with self.driver.session() as session:
            for name, query in verification_queries.items():
                result = session.run(query)
                count = result.single()["count"]
                print(f"  📊 {name}: {count}")
        
        # ✅ Check region-specific data
        print("\n🌍 Data by region:")
        with self.driver.session() as session:
            for region in self.regions:
                result = session.run("MATCH (n) WHERE n.region = $region RETURN count(n) as count", {"region": region})
                count = result.single()["count"]
                print(f"  📍 {region}: {count} nodes")
                
                # Check relationships for this region
                result = session.run("""
                    MATCH (n)-[r]->(m) 
                    WHERE n.region = $region OR m.region = $region 
                    RETURN count(r) as count
                """, {"region": region})
                rel_count = result.single()["count"]
                print(f"    🔗 {region} relationships: {rel_count}")
        
        # ✅ Sample data verification
        print("\n🔍 Sample data verification:")
        with self.driver.session() as session:
            # Sample NAI data (what your frontend is requesting)
            result = session.run("MATCH (c:CONSULTANT) WHERE c.region = 'NAI' RETURN c.name, c.id LIMIT 1")
            if result.peek():
                record = result.single()
                print(f"  👤 Sample NAI Consultant: {record['c.name']} (ID: {record['c.id']})")
            
            # Sample relationship chain
            result = session.run("""
                MATCH (c:CONSULTANT)-[:EMPLOYS]->(fc:FIELD_CONSULTANT)-[:COVERS]->(co:COMPANY)-[:OWNS]->(p:PRODUCT)
                WHERE c.region = 'NAI'
                RETURN c.name, fc.name, co.name, p.name
                LIMIT 1
            """)
            if result.peek():
                record = result.single()
                print(f"  🔗 Sample relationship chain:")
                print(f"    {record['c.name']} -> {record['fc.name']} -> {record['co.name']} -> {record['p.name']}")


def main():
    """Main setup function."""
    print("=" * 70)
    print("🎯 FIXED: Smart Network Neo4j Database Setup")
    print("=" * 70)
    print(f"🔗 Connecting to: {NEO4J_URI}")
    print(f"👤 Username: {NEO4J_USERNAME}")
    print("🗃️ This will create proper nodes and relationships")
    print()
    
    setup = SmartNetworkSetup()
    
    # Test connection first
    if not setup.test_connection():
        print("\n❌ Cannot connect to Neo4j. Please check:")
        print("  1. Neo4j is running: brew services start neo4j")
        print("  2. Update NEO4J_PASSWORD in the script")
        print("  3. Check Neo4j Browser: http://localhost:7474")
        return
    
    # Confirm before proceeding
    response = input("⚠️ This will CLEAR ALL existing data. Continue? (y/N): ")
    if response.lower() != 'y':
        print("❌ Setup cancelled")
        return
    
    try:
        # Step 1: Clear existing data
        setup.clear_database()
        
        # Step 2: Create constraints and indexes
        setup.create_constraints_and_indexes()
        
        # Step 3: Generate sample data with proper relationships
        setup.generate_sample_data()
        
        # Step 4: Verify setup
        setup.verify_setup()
        
        print("\n" + "=" * 70)
        print("🎉 Database setup completed successfully!")
        print("🌐 NAI region now has proper data with relationships!")
        print()
        print("📋 Next steps:")
        print("   1. View data in Neo4j Browser: http://localhost:7474")
        print("   2. Run this query to see NAI data:")
        print("      MATCH (n) WHERE n.region = 'NAI' RETURN n LIMIT 25")
        print("   3. Start your FastAPI backend")
        print("   4. Test frontend with proper NAI relationships")
        print("=" * 70)
        
    except Exception as e:
        print(f"❌ Setup failed: {e}")
        import traceback
        traceback.print_exc()
    finally:
        setup.close()


if __name__ == "__main__":
    main()