"""
API endpoints implementing the hierarchical filter population process.
Following the exact workflow: Region Selection → Data Retrieval → Filter Population
"""
from typing import Dict, List, Any, Optional
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from app.services.hierarchical_filter_service import hierarchical_filter_service
from app.config import REGIONS


# Pydantic models for request/response
class RegionDataResponse(BaseModel):
    """Response model for region data with populated filters."""
    success: bool
    region: str
    data: Dict[str, Any]
    filters: Dict[str, Any]
    metadata: Dict[str, Any]


class FilterOptionsResponse(BaseModel):
    """Response model for filter options."""
    region: str
    filter_options: Dict[str, Any]
    metadata: Dict[str, Any]


# Create router for hierarchical filter endpoints
hierarchical_router = APIRouter(
    prefix="/hierarchical",
    tags=["Hierarchical Filters"]
)


@hierarchical_router.get("/regions")
async def get_available_regions():
    """Get list of available regions for selection."""
    try:
        return {
            "success": True,
            "regions": hierarchical_filter_service.get_available_regions(),
            "default_region": "NAI",
            "description": "Available regions for hierarchical filter population"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get regions: {str(e)}")


@hierarchical_router.get("/region/{region}/complete")
async def get_region_complete_workflow(region: str):
    """
    Complete hierarchical workflow:
    1. Initial Region Selection → Get ALL nodes and relationships for region
    2. First-Level Filter Population → Extract unique values for dropdowns
    
    This is the main endpoint that implements your exact approach.
    """
    try:
        # Validate region
        if not hierarchical_filter_service.validate_region(region):
            raise HTTPException(
                status_code=400,
                detail=f"Invalid region: {region}. Must be one of: {REGIONS}"
            )
        
        # Execute complete workflow
        result = hierarchical_filter_service.get_region_with_filters(region.upper())
        
        if not result["success"]:
            raise HTTPException(
                status_code=500,
                detail=f"Failed to process region {region}: {result.get('error')}"
            )
        
        return {
            "success": True,
            "message": f"Hierarchical filter population completed for {region}",
            "workflow_steps": [
                "✓ Step 1: Retrieved all nodes and relationships for region",
                "✓ Step 2: Populated filters based on region data",
                "✓ All dropdown options are contextually relevant to selected region"
            ],
            "data": {
                "region": result["region"],
                "graph_data": {
                    "nodes": result["data"]["nodes"],
                    "relationships": result["data"]["relationships"]
                },
                "filter_options": result["filters"],
                "statistics": {
                    "total_nodes": result["data"]["metadata"]["node_count"],
                    "total_relationships": result["data"]["metadata"]["relationship_count"],
                    "total_filter_options": result["metadata"]["filter_metadata"]["total_options_count"]
                }
            },
            "metadata": result["metadata"]
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Workflow failed: {str(e)}")


@hierarchical_router.get("/region/{region}/data")
async def get_region_data_only(region: str):
    """
    Step 1 Only: Get ALL nodes and relationships for the specified region.
    This triggers the filter_graph() function to retrieve region data.
    """
    try:
        if not hierarchical_filter_service.validate_region(region):
            raise HTTPException(
                status_code=400,
                detail=f"Invalid region: {region}. Must be one of: {REGIONS}"
            )
        
        region_data = hierarchical_filter_service.get_region_data(region.upper())
        
        return {
            "success": True,
            "message": f"Retrieved all data for region {region}",
            "region": region.upper(),
            "data": region_data,
            "summary": {
                "nodes_retrieved": len(region_data["nodes"]),
                "relationships_retrieved": len(region_data["relationships"]),
                "node_types": list(set([
                    label for node in region_data["nodes"] 
                    for label in node.get("labels", [])
                ])),
                "relationship_types": list(set([
                    rel["type"] for rel in region_data["relationships"]
                ]))
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get region data: {str(e)}")


@hierarchical_router.post("/region/{region}/filters")
async def populate_filters_from_data(region: str, region_data: Dict[str, Any]):
    """
    Step 2 Only: Populate filters based on provided region data.
    This demonstrates the filter population logic using existing data.
    """
    try:
        if not hierarchical_filter_service.validate_region(region):
            raise HTTPException(
                status_code=400,
                detail=f"Invalid region: {region}. Must be one of: {REGIONS}"
            )
        
        filter_data = hierarchical_filter_service.populate_filter_options(region_data)
        
        return {
            "success": True,
            "message": f"Populated filters based on {region} data",
            "region": region.upper(),
            "filter_options": filter_data["filter_options"],
            "breakdown": {
                "markets": len(filter_data["filter_options"].get("markets", [])),
                "channels": len(filter_data["filter_options"].get("channels", [])),
                "field_consultants": len(filter_data["filter_options"].get("field_consultants", [])),
                "products": len(filter_data["filter_options"].get("products", [])),
                "companies": len(filter_data["filter_options"].get("companies", [])),
                "consultants": len(filter_data["filter_options"].get("consultants", [])),
                "consultant_rankings": len(filter_data["filter_options"].get("consultant_rankings", [])),
                "influence_levels": len(filter_data["filter_options"].get("influence_levels", [])),
                "asset_classes": len(filter_data["filter_options"].get("asset_classes", [])),
                "client_advisors": len(filter_data["filter_options"].get("client_advisors", []))
            },
            "metadata": filter_data["metadata"]
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to populate filters: {str(e)}")


@hierarchical_router.put("/region/change/{new_region}")
async def change_region(new_region: str, current_region: Optional[str] = Query(None)):
    """
    Step 3: Region Change Handler
    When region changes → fetch new data → update all filters
    This implements the dynamic update workflow.
    """
    try:
        if not hierarchical_filter_service.validate_region(new_region):
            raise HTTPException(
                status_code=400,
                detail=f"Invalid region: {new_region}. Must be one of: {REGIONS}"
            )
        
        # Execute region change workflow
        result = hierarchical_filter_service.change_region(new_region.upper())
        
        if not result["success"]:
            raise HTTPException(
                status_code=500,
                detail=f"Failed to change region to {new_region}: {result.get('error')}"
            )
        
        return {
            "success": True,
            "message": f"Region changed from {current_region or 'unknown'} to {new_region}",
            "workflow_executed": [
                f"→ Detected region change to {new_region}",
                "→ Fetched new data from Neo4j", 
                "→ Updated all filter options",
                "→ All dropdowns now show contextually relevant options"
            ],
            "previous_region": current_region,
            "new_region": result["region"],
            "updated_data": {
                "graph_data": {
                    "nodes": result["data"]["nodes"],
                    "relationships": result["data"]["relationships"]
                },
                "filter_options": result["filters"]
            },
            "change_summary": {
                "new_node_count": result["data"]["metadata"]["node_count"],
                "new_relationship_count": result["data"]["metadata"]["relationship_count"],
                "new_filter_options_count": result["metadata"]["filter_metadata"]["total_options_count"]
            },
            "metadata": result["metadata"]
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Region change failed: {str(e)}")


@hierarchical_router.get("/region/{region}/filters/breakdown")
async def get_filter_breakdown(region: str):
    """
    Get detailed breakdown of how each filter option is populated.
    This shows the exact implementation of your hierarchical approach.
    """
    try:
        if not hierarchical_filter_service.validate_region(region):
            raise HTTPException(
                status_code=400,
                detail=f"Invalid region: {region}. Must be one of: {REGIONS}"
            )
        
        # Get complete workflow result
        result = hierarchical_filter_service.get_region_with_filters(region.upper())
        
        if not result["success"]:
            raise HTTPException(status_code=500, detail=result.get('error'))
        
        # Create detailed breakdown
        breakdown = {
            "region": region.upper(),
            "filter_population_process": {
                "1_markets_list": {
                    "description": "Extracts unique sales regions from companies in selected region",
                    "method": "get_param_filter_list('sales_region', companies, True)",
                    "count": len(result["filters"].get("markets", [])),
                    "values": result["filters"].get("markets", [])
                },
                "2_channels_list": {
                    "description": "Extracts unique channel values from companies in selected region", 
                    "method": "get_param_filter_list('channel', companies, True)",
                    "count": len(result["filters"].get("channels", [])),
                    "values": result["filters"].get("channels", [])
                },
                "3_field_consultants": {
                    "description": "Retrieves field consultants connected to companies in selected region",
                    "method": "get_node_filter_list('FIELD_CONSULTANT', elements)",
                    "count": len(result["filters"].get("field_consultants", [])),
                    "sample": result["filters"].get("field_consultants", [])[:5]
                },
                "4_products": {
                    "description": "Gets products owned by companies in selected region",
                    "method": "get_node_filter_list('PRODUCT', elements)",
                    "count": len(result["filters"].get("products", [])),
                    "sample": result["filters"].get("products", [])[:5]
                },
                "5_companies": {
                    "description": "Lists companies in selected region",
                    "method": "get_node_filter_list('COMPANY', elements)",
                    "count": len(result["filters"].get("companies", [])),
                    "sample": result["filters"].get("companies", [])[:5]
                },
                "6_consultants": {
                    "description": "Gets consultants connected to companies in selected region",
                    "method": "get_node_filter_list('CONSULTANT', elements)",
                    "count": len(result["filters"].get("consultants", [])),
                    "sample": result["filters"].get("consultants", [])[:5]
                },
                "7_consultant_rankings": {
                    "description": "Gets unique ranking values from RATES relationships",
                    "method": "get_param_filter_list('rankgroup', relationships, True)",
                    "count": len(result["filters"].get("consultant_rankings", [])),
                    "values": result["filters"].get("consultant_rankings", [])
                },
                "8_influence_levels": {
                    "description": "Extracts unique influence level values from relationships",
                    "method": "get_param_filter_list('level_of_influence', relationships, True)",
                    "count": len(result["filters"].get("influence_levels", [])),
                    "values": result["filters"].get("influence_levels", [])
                },
                "9_asset_classes": {
                    "description": "Gets unique asset class values from products",
                    "method": "get_param_filter_list('asset_class', products, True)",
                    "count": len(result["filters"].get("asset_classes", [])),
                    "values": result["filters"].get("asset_classes", [])
                },
                "10_client_advisors": {
                    "description": "Retrieves client advisor names (PCAs and ACAs) from companies",
                    "method": "get_ca_names(region, market_options)",
                    "count": len(result["filters"].get("client_advisors", [])),
                    "sample": result["filters"].get("client_advisors", [])[:10]
                }
            },
            "summary": {
                "total_source_nodes": result["data"]["metadata"]["node_count"],
                "total_source_relationships": result["data"]["metadata"]["relationship_count"],
                "total_filter_options_generated": result["metadata"]["filter_metadata"]["total_options_count"],
                "contextual_relevance": "All filter options are contextually relevant to the selected region"
            }
        }
        
        return breakdown
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get filter breakdown: {str(e)}")


@hierarchical_router.get("/health")
async def health_check():
    """Health check for hierarchical filter service."""
    try:
        is_healthy = hierarchical_filter_service.health_check()
        
        return {
            "status": "healthy" if is_healthy else "unhealthy",
            "service": "Hierarchical Filter Service",
            "database_connected": is_healthy,
            "available_regions": REGIONS,
            "workflow_ready": is_healthy
        }
        
    except Exception as e:
        return {
            "status": "unhealthy",
            "service": "Hierarchical Filter Service", 
            "error": str(e),
            "database_connected": False,
            "workflow_ready": False
        }